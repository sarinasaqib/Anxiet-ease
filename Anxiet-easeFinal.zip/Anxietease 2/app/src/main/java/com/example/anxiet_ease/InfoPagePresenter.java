package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.method.LinkMovementMethod;
import android.widget.ImageButton;
import android.widget.TextView;

public class InfoPagePresenter implements IPresenter{
    // Presenter for the InfoPage activity
    private Context context;
    private Activity activity;

    public InfoPagePresenter(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    public void callButton(ImageButton button){

        //when the call button is clicked, the user will be taken to the phone app on their mobile
        // the number for the suicide prevention hotline will already be entered user just needs to hit dial
        button.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:116123"));
            context.startActivity(intent);
        });
    }

    @Override
    public void homeButton(ImageButton button) {
        button.setOnClickListener(v -> activity.finish());
    }

    public void setLinks(TextView tv1, TextView tv2, TextView tv3) {
        //set the movement, when user clicks on the text they will be taken to relevant link
        //on their mobile internet browser
        tv1.setMovementMethod(LinkMovementMethod.getInstance());
        tv2.setMovementMethod(LinkMovementMethod.getInstance());
        tv3.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
