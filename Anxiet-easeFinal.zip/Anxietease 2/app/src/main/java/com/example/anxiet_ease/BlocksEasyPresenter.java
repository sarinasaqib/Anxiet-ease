package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class BlocksEasyPresenter implements BlockLevels {
    // Presenter for the Blocks easy activity
    private Context context;
    private Activity activity;
    private ArrayList<Button> blocks;
    private TextView txt_score;
    private Random random;
    public boolean boo = false;
    public Thread thread1;
    public boolean running;
    public int score = 0;
    public Button target;

    public BlocksEasyPresenter(Context context, Activity activity, ArrayList<Button> blocks, TextView txt) {
        this.context = context;
        this.activity = activity;
        this.blocks = blocks;
        this.txt_score = txt;
        random = new Random(); //random used to generate a new random target from an array

    }

    @Override
    public void homeButton(ImageButton button) {
        //stop the threads running, and finish the activity
        //but also start the home activity when user clicks home button

        button.setOnClickListener(v -> {
            clearGame();
            boo = false;
            setRunning(false);
            activity.finish();
            context.startActivity(new Intent(context, Home.class));
        });
    }

    @Override
    public void speedMenu(Button button) {
        //stop the threads and finish the activity
        //to take use back to previous activity, blocks, which has the speed menu
        button.setOnClickListener(v -> {
            clearGame();
            boo = false;
            setRunning(false);
            activity.finish();
        });
    }

    @Override
    public void clearGame() {
        //set the target button to the original colour
        // deactivate the onclick to add a point a generate a new target
        target.setBackgroundColor(Color.parseColor("#9c91ed"));
        target.setOnClickListener(null);
    }

    @Override
    public void resetButton(ImageButton button) {
        //reset the score
        button.setOnClickListener(v -> {
            this.score = 0;
            this.txt_score.setText("" + score);
        });
    }

    @Override
    public void setRunning(boolean running) {
        this.running = running;
    }

    @Override
    public void targetButton() {
        //set a starting target button using a random block in the array and change the colour
        target = blocks.get(new Random().nextInt(blocks.size()));
        target.setBackgroundColor(Color.parseColor("#d4e263"));

        Runnable clickButtons = () -> {
            while (running) {
                target.setOnClickListener(v -> {
                    score++;
                    txt_score.setText("" + score);
                    boo = true;
                });
                while (boo) {
                    target.setBackgroundColor(Color.parseColor("#9c91ed"));
                    target.setOnClickListener(null);
                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException e) {

                    }
                    target = blocks.get(new Random().nextInt(blocks.size()));
                    target.setBackgroundColor(Color.parseColor("#d4e263"));
                    boo = false;
                }
            }
            //if the user clicks the button add a point and set boo to true which controls the next target
            //deactivate target
            // interrupt thread to start it again from sleeping
            //sleep the thread to give a gap after the user clicks the target button and the next target being set
            // set new target
            clearGame();

        };
        thread1 = new Thread(clickButtons);
        running = true;
        thread1.start();
    }

    @Override
    public void destroy() {
        boo = false;
        setRunning(false);
        thread1.interrupt();
        score = 0;
        clearGame();

        boolean retry = true;
        while (retry) {
            try {
                setRunning(false);
                thread1.join();


            } catch (Exception e) {
                e.printStackTrace();
            }
            retry = false;

        }
    }
}
