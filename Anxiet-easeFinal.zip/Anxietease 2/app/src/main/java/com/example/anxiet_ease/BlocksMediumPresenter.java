package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class BlocksMediumPresenter implements BlockLevels {

    // Presenter for the Blocks normal activity
    private Context context;
    private Activity activity;
    private ArrayList<Button> blocks;
    private TextView txt_score;
    private Random random;
    public boolean boo = false;
    public Thread thread1;
    public boolean running;
    public int score = 0;
    public Button target;

    public BlocksMediumPresenter(Context context, Activity activity, ArrayList<Button> blocks, TextView txt) {
        this.context = context;
        this.activity = activity;
        this.blocks = blocks;
        this.txt_score = txt;
        random = new Random(); //random used to generate a new random target from an array

    }

    @Override
    public void homeButton(ImageButton button) {
        //on the back button clear the game and stop the thread from running, and setting the looping booleans false before finishing the activty
        //start the home activity bc finish will just take the user back to the speed menu page
        button.setOnClickListener(v -> {
            clearGame();
            boo = false;
            setRunning(false);
            activity.finish();
            context.startActivity(new Intent(context, Home.class));
        });
    }
    @Override
    public void speedMenu(Button button) {
        //stop the game running to false and set booleans to false before finishing and taking the user back to to the speed menu

        button.setOnClickListener(v -> {
            clearGame();
            boo = false;
            setRunning(false);
            activity.finish();
        });
    }

    @Override
    public void clearGame() {
        //clear the game sets all the buttons to the same original colour and stops the on click listener
        //meaning the user cant see a target or score

        target.setBackgroundColor(Color.parseColor("#9c91ed"));
        target.setOnClickListener(null);
    }

    @Override
    public void resetButton(ImageButton button) {
        //resets the score

        button.setOnClickListener(v -> {
            score = 0;
            txt_score.setText("" + score);
        });
    }

    @Override
    public void setRunning(boolean running) {
        this.running = running;
    }

    @Override
    public void targetButton() {
        //set the first target button through picking a random block on the array
        //set the target a different colour
        target = blocks.get(new Random().nextInt(blocks.size()));
        target.setBackgroundColor(Color.parseColor("#d4e263"));

        Runnable clickButtons = () -> {
            while (running) {
                target.setOnClickListener(v -> {
                    //if the user clicks the target give them a point set the boolean to true for new taregt
                    score++;
                    txt_score.setText("" + score);
                    boo = true;
                });

                while (boo) {
                    //when boo is true it deactivates the current target and gives a new one
                    //deactivate target
                    target.setBackgroundColor(Color.parseColor("#9c91ed"));
                    target.setOnClickListener(null);

                    // set new target
                    target = blocks.get(new Random().nextInt(blocks.size()));
                    target.setBackgroundColor(Color.parseColor("#d4e263"));
                    boo = false;
                }
            }
            //clear game when stopped running
            clearGame();
        };
        thread1 = new Thread(clickButtons);
        running = true;
        thread1.start();
    }

    @Override
    public void destroy() {
        //to kill all the threads
        boo = false;
        setRunning(false);
        thread1.interrupt();
        score = 0;
        clearGame();

        boolean retry = true;
        while (retry) {
            try {
                setRunning(false);
                thread1.join();
            } catch (Exception e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }
}
