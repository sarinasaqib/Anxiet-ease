package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class BlocksHardPresenter implements BlockLevels {
    // Presenter for the Blocks hard activity
    private Context context;
    private Activity activity;
    private ArrayList<Button> blocks;
    private TextView txt_score;
    private Random random;
    public boolean boo = false;
    public Thread thread1;
    public Thread thread2;
    public boolean running;
    public int score = 0;
    public Button target;
    public boolean isInterrupted;

    public BlocksHardPresenter(Context context, Activity activity, ArrayList<Button> blocks, TextView txt) {
        this.context = context;
        this.activity = activity;
        this.blocks = blocks;
        this.txt_score = txt;
        random = new Random(); //random used to generate a new random target from an array

    }

    @Override
    public void homeButton(ImageButton button) {
        //on the back button clear the game and stop the thread from running, and setting the looping booleans false before finishing the activty
        //on click need to stoop the threads and game running before calling finish
        //start the home activity after finish, as finish will just take the user back to the speed menu page

        button.setOnClickListener(v -> {
            clearGame();
            boo = false;
            setRunning(false);
            activity.finish();
            context.startActivity(new Intent(context, Home.class));
        });
    }

    @Override
    public void speedMenu(Button button) {
        // on click need to stoop the threads and game running before calling finish
        //call finish to take the user to the previous activity, blocks, which has the speed menu
        button.setOnClickListener(v -> {
            clearGame();
            boo = false;
            setRunning(false);
            activity.finish();
        });
    }

    @Override
    public void clearGame() {
        //gets rid of the different colour target and any response from clicking the button

        target.setBackgroundColor(Color.parseColor("#9c91ed"));
        target.setOnClickListener(null);
    }

    @Override
    public void resetButton(ImageButton button) {
        //rests the score

        button.setOnClickListener(v -> {
            score = 0;
            txt_score.setText("" + score);
        });
    }

    @Override
    public void setRunning(boolean running) {
        this.running = running;
    }

    @Override
    public void targetButton() {
        // Random timer global int. set sleep to new time value 500-2500
        isInterrupted = false;
        //set the first target button, by getting a random block from the array
        //set the colour so the user knows its target

        target = blocks.get(new Random().nextInt(blocks.size()));
        target.setBackgroundColor(Color.parseColor("#d4e263"));

        //hard level follows a wac-a-mole style generation of targets
        // the timers moves to a new target button after a specified number of second when the user doesnt click it

        Runnable timerButtons = () -> {
            while (running) {
                try {
                    if(isInterrupted) {
                        Thread.sleep(2000);
                        isInterrupted = false;
                    }
                    Thread.sleep(1000);
                    boo = true;
                    Thread.sleep(2000);

                } catch (InterruptedException e) {
                    //e.printStackTrace();
                    System.out.println("INTERRUPTED");
                    isInterrupted = true;
                }

            }
            //clear game when stopped running
            clearGame();
        };

        thread1 = new Thread(timerButtons);
        //if the user clicks the button add a point and set boo to true which controls the next target
        // interrupt thread to start it again from sleep

        Runnable clickButtons = () -> {
            while (running) {
                target.setOnClickListener(v -> {
                    thread1.interrupt();
                    score++;
                    txt_score.setText("" + score);
                    boo = true;

                });
                while (boo) {
                    target.setBackgroundColor(Color.parseColor("#9c91ed"));
                    target.setOnClickListener(null);

                    //deactivate the target and then sleep the thread to add a gap before the next target appears

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    // set new target
                    target = blocks.get(new Random().nextInt(blocks.size()));
                    target.setBackgroundColor(Color.parseColor("#d4e263"));

                    boo = false;
                }
            }
            //clear game when stopped running
            clearGame();
        };
        thread2 = new Thread(clickButtons);
        running = true;
        thread1.start();
        thread2.start();
    }

    @Override
    public void destroy() {
        boo = false;
        setRunning(false);
        thread1.interrupt();
        thread2.interrupt();
        score = 0;
        clearGame();


        boolean retry = true;
        while (retry) {
            try {
                setRunning(false);
                thread1.join();
                thread2.join();

            } catch (Exception e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }
}
