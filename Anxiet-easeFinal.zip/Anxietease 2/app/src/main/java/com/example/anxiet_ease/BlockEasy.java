package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class BlockEasy extends AppCompatActivity implements IView{

    private BlocksEasyPresenter presenter;
    Button button1, button2, button3, button4, button5, button6, button7, button8, button9;
    TextView txt_score;
    public ArrayList<Button> blocks = new ArrayList<>();
    ImageButton backButton;
    Button speedMenu;
    ImageButton resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocks_game);

        //find all the buttons on the XML and add them to the blocks array
        button1 = findViewById(R.id.block1);
        button2 = findViewById(R.id.block2);
        button3 = findViewById(R.id.block3);
        button4 = findViewById(R.id.block4);
        button5 = findViewById(R.id.block5);
        button6 = findViewById(R.id.block6);
        button7 = findViewById(R.id.block7);
        button8 = findViewById(R.id.block8);
        button9 = findViewById(R.id.block9);

        txt_score = findViewById(R.id.txt_score);
        backButton = findViewById(R.id.blocksHome);
        speedMenu = findViewById(R.id.speedMenu);
        resetButton = findViewById(R.id.reset);

        blocks.add(button1);
        blocks.add(button2);
        blocks.add(button3);
        blocks.add(button4);
        blocks.add(button5);
        blocks.add(button6);
        blocks.add(button7);
        blocks.add(button8);
        blocks.add(button9);

        setPresenter(new BlocksEasyPresenter(this.getContext(), this.getActivity(), blocks, txt_score));

        presenter.homeButton(backButton);
        presenter.speedMenu(speedMenu);
        presenter.resetButton(resetButton);
        presenter.targetButton();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        presenter.destroy();
    }

    private void setPresenter(BlocksEasyPresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}
