package com.example.anxiet_ease;
// Sarina Saqib 2249047
//Inspiration for the basis of the maze game taken from ReteroChicken on youtube https://www.youtube.com/watch?v=OojQitoAEXs&t=2s&ab_channel=RetroChicken
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MazeGame extends AppCompatActivity implements IView {

    private MazeGamePresenter presenter;
    public Button speedMenu;
    public ImageButton MazeHome;
    public View gv;
    @SuppressLint("StaticFieldLeak")
    public static TextView txt_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        //stores the screen dimensions in the constants class
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        Constants.SCREEN_WIDTH = dm.widthPixels;
        Constants.SCREEN_HEIGHT = dm.heightPixels;

        //set the view of the activity to the main maze with the game panel view in it
        setContentView(R.layout.activity_maze_game);
        setPresenter(new MazeGamePresenter(this.getContext(), this.getActivity()));

        speedMenu = findViewById(R.id.speedMenuMaze);
        txt_score = findViewById(R.id.score);
        gv = findViewById(R.id.view);
        MazeHome = findViewById(R.id.MazeGameHome);

        presenter.homeButton(MazeHome);
        presenter.speedMenu(speedMenu);

    }

    private void setPresenter(MazeGamePresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}