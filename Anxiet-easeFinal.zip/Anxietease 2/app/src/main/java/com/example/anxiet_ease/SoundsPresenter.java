package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.widget.Button;
import android.widget.ImageButton;

public class SoundsPresenter implements IPresenter {

    private Context context;
    private Activity activity;
    private Button pinkNoiseControl;
    private MediaPlayer pinkNoise;
    private Button wavesControl;
    private MediaPlayer waves;
    private Button rainControl;
    private MediaPlayer rain;
    private Button birdsControl;
    private MediaPlayer birds;
    private Button classicalControl;
    private MediaPlayer classical;
    private Button lofiControl;
    private MediaPlayer lofi;
    private Drawable play;
    private Drawable pause;
    private int heightPlay;
    private int widthPlay;
    private int heightPause;
    private int widthPause;

    public SoundsPresenter(Context context, Activity activity, Drawable play, Drawable pause,
                           Button pinkNoiseButton, Button wavesButton, Button rainButton, Button birdsButton,
                           Button classicalButton, Button lofiButton, MediaPlayer pinkNoiseSound,
                           MediaPlayer wavesSound, MediaPlayer rainSound, MediaPlayer birdsSound,
                           MediaPlayer classicalSound, MediaPlayer lofiSound) {
        this.context = context;
        this.activity = activity;
        this.play = play;
        this.pause = pause;
        this.heightPlay = play.getIntrinsicHeight();
        this.widthPlay = play.getIntrinsicWidth();
        this.heightPause = pause.getIntrinsicHeight();
        this.widthPause = pause.getIntrinsicWidth();
        this.pinkNoiseControl = pinkNoiseButton;
        this.pinkNoise = pinkNoiseSound;
        this.wavesControl = wavesButton;
        this.waves = wavesSound;
        this.rainControl = rainButton;
        this.rain = rainSound;
        this.birdsControl = birdsButton;
        this.birds = birdsSound;
        this.classicalControl = classicalButton;
        this.classical = classicalSound;
        this.lofiControl = lofiButton;
        this.lofi = lofiSound;

        this.play.setBounds(0, 0, this.widthPlay, this.heightPlay );
        this.pause.setBounds(0, 0, this.widthPause, this.heightPause );
    }

    @Override
    public void homeButton(ImageButton button) {
        button.setOnClickListener(v -> {
            classical.release();
            waves.release();
            rain.release();
            birds.release();
            pinkNoise.release();
            lofi.release();
            activity.finish();

            //release all of the media players before you exit finish the activity to free resources

        });
    }
    //if the media player is playing the user will want to pause the media player
    //set the button image to play again
    //if its not playing  and is clicked the calming sounds will loop
    //and the button will show a pause image
    public void wavesSound(){
        wavesControl.setCompoundDrawables(null, null, null, play);
        //start the image button with a play image on the bottom of the button

        wavesControl.setOnClickListener(v -> {
            if (waves.isPlaying()){
                waves.pause();
                wavesControl.setCompoundDrawables( null, null, null, play );
            }else {
                pauseAll();
                waves.setLooping(true);
                waves.start();
                wavesControl.setCompoundDrawables( null, null, null, pause );
            }
        });
    }

    public void pinkNoiseSound(){
        pinkNoiseControl.setCompoundDrawables(null, null, null, play);
        //start the image button with a play image on the bottom of the button

        pinkNoiseControl.setOnClickListener(v -> {
            if (pinkNoise.isPlaying()) {
                pinkNoise.pause();
                pinkNoiseControl.setCompoundDrawables( null, null, null, play );

                //if the media player is playing the user will want to pause the media player
                //set the button image to play again

            } else {
                pauseAll();
                pinkNoise.setLooping(true);
                pinkNoise.start();
                pinkNoiseControl.setCompoundDrawables( null, null, null, pause );

                //if its not playing  and is clicked the calming sounds will loop
                //and the button will show a pause image
            }
        });
    }

    public void rainSound(){
        rainControl.setCompoundDrawables(null, null, null, play);
        //start the image button with a play image on the bottom of the button

        rainControl.setOnClickListener(v -> {

            if (rain.isPlaying()) {
                rain.pause();
                rainControl.setCompoundDrawables( null, null, null, play );

                //if the media player is playing the user will want to pause the media player
                //set the button image to play again

            } else {
                pauseAll();
                rain.setLooping(true);
                rain.start();
                rainControl.setCompoundDrawables( null, null, null, pause );

                //if its not playing  and is clicked the calming sounds will loop
                //and the button will show a pause image
            }
        });
    }

    public void classicalSound(){
        classicalControl.setCompoundDrawables(null, null, null, play);
        //start the image button with a play image on the bottom of the button

        classicalControl.setOnClickListener(v -> {

            if (classical.isPlaying()){
                classical.pause();
                classicalControl.setCompoundDrawables( null, null, null, play );

                //if the media player is playing the user will want to pause the media player
                //set the button image to play again

            }else {
                pauseAll();
                classical.setLooping(true);
                classical.start();
                classicalControl.setCompoundDrawables( null, null, null, pause );

                //if its not playing  and is clicked the calming sounds will loop
                //and the button will show a pause image
            }
        });
    }

    public void birdSound(){
        birdsControl.setCompoundDrawables(null, null, null, play);
        //start the image button with a play image on the bottom of the button

        birdsControl.setOnClickListener(v -> {

            if (birds.isPlaying()){
                birds.pause();
                birdsControl.setCompoundDrawables( null, null, null, play );

                //if the media player is playing the user will want to pause the media player
                //set the button image to play again

            }else {
                pauseAll();
                birds.setLooping(true);
                birds.start();
                birdsControl.setCompoundDrawables( null, null, null, pause );

                //if its not playing  and is clicked the calming sounds will loop
                //and the button will show a pause image
            }
        });
    }

    public void lofiSound(){
        lofiControl.setCompoundDrawables(null, null, null, play);
        //start the image button with a play image on the bottom of the button

        lofiControl.setOnClickListener(v -> {

            if (lofi.isPlaying()){
                lofi.pause();
                lofiControl.setCompoundDrawables( null, null, null, play );

                //if the media player is playing the user will want to pause the media player
                //set the button image to play again

            }else {
                pauseAll();
                lofi.setLooping(true);
                lofi.start();
                lofiControl.setCompoundDrawables( null, null, null, pause );

                //if its not playing  and is clicked the calming sounds will loop
                //and the button will show a pause image
            }
        });
    }
    //if you click it and any of the other players are playing then pause the other player
    //and set each picture of the button to play
    // so only one player will play at once
    private void pauseAll() {
        if(waves.isPlaying()){
            waves.pause();
            wavesControl.setCompoundDrawables( null, null, null, play );
        }if(rain.isPlaying()){
            rain.pause();
            rainControl.setCompoundDrawables( null, null, null, play );
        }if(birds.isPlaying()){
            birds.pause();
            birdsControl.setCompoundDrawables( null, null, null, play );
        }if(classical.isPlaying()){
            classical.pause();
            classicalControl.setCompoundDrawables( null, null, null, play );
        }if(pinkNoise.isPlaying()){
            pinkNoise.pause();
            pinkNoiseControl.setCompoundDrawables( null, null, null, play );
        }if(lofi.isPlaying()){
            lofi.pause();
            lofiControl.setCompoundDrawables( null, null, null, play );
        }
    }
}
