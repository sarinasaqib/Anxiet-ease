package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;

public interface IView {
    // Interface to Views
    Context getContext();
    Activity getActivity();
}
