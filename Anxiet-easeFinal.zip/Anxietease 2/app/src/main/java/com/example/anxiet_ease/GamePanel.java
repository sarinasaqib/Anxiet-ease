package com.example.anxiet_ease;
//Inspiration for the basis of the maze game taken from ReteroChicken on youtube https://www.youtube.com/watch?v=OojQitoAEXs&t=2s&ab_channel=RetroChicken
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.Nullable;
// Sarina Saqib 2249047
public class GamePanel extends SurfaceView implements SurfaceHolder.Callback {
    public static MainThread thread;
    private Rect r = new Rect();
    private Player player;
    private Point playerPoint;
    private MapManager mapManager;
    public int sumPipe;
    public static int score = 0;

    public static boolean rectPoint = false;
    private boolean movingPlayer = false;

    public static boolean gameOver = false;

    public GamePanel(Context context, @Nullable AttributeSet attrs) {
        super(context);
        getHolder().addCallback(this);
        thread = new MainThread(getHolder(), this);

        // the if statement decides which speed level is implemented using the booleans from the buttons on the start page

        if (MazePresenter.slow) {
            mapManager = new MapManager(200, 350, 75, Color.parseColor("#9c91ed"), Constants.SCREEN_HEIGHT / 10000.0f);
        }
        if (MazePresenter.normal) {
            mapManager = new MapManager(200, 350, 75, Color.parseColor("#9c91ed"), Constants.SCREEN_HEIGHT / 5000.0f);
        }
        if (MazePresenter.fast) {
            mapManager = new MapManager(200, 350, 75, Color.parseColor("#9c91ed"), Constants.SCREEN_HEIGHT / 3000.0f);
        }

        //generate a new player making it smaller than the player gap for the walls
        // the player point is constantly updated to remain in the middle of the player

        player = new Player(new Rect(100, 100, 200, 200), Color.parseColor("#9c91ed"));
        playerPoint = new Point(Constants.SCREEN_WIDTH / 2, 3 * Constants.SCREEN_HEIGHT / 4);
        player.update(playerPoint);

        setFocusable(true);
    }


    public void reset() {

        //reset the player point to the original point and reset the walls to start generating from the top of the screen

        playerPoint = new Point(Constants.SCREEN_WIDTH / 2, 3 * Constants.SCREEN_HEIGHT / 4);
        player.update(playerPoint);
        if (MazePresenter.slow) {
            mapManager = new MapManager(200, 350, 75, Color.parseColor("#9c91ed"), Constants.SCREEN_HEIGHT / 10000.0f);
        }
        if (MazePresenter.normal) {
            mapManager = new MapManager(200, 350, 75, Color.parseColor("#9c91ed"), Constants.SCREEN_HEIGHT / 5000.0f);
        }
        if (MazePresenter.fast) {
            mapManager = new MapManager(200, 350, 75, Color.parseColor("#9c91ed"), Constants.SCREEN_HEIGHT / 3000.0f);
        }

        movingPlayer = false;
        score = 0;

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread = new MainThread(getHolder(), this);

        thread.setRunning(true);
        thread.start();

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        reset();
        gameOver = false;
        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();

            } catch (Exception e) {
                e.printStackTrace();
            }
            retry = false;

        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (!gameOver && player.getRectangle().contains((int) event.getX(), (int) event.getY()))
                    //if the on touch event is in the player rect set the moving player to true

                    movingPlayer = true;

                if (gameOver) {
                    //tap the screen to start again on game over
                    reset();
                    gameOver = false;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (!gameOver && movingPlayer) {
                    //set the player point to where ever the user is moving the player to

                    playerPoint.set((int) event.getX(),(int) event.getY());
                }
                break;

            case MotionEvent.ACTION_UP:
                //stop moving the player

                movingPlayer = false;
                break;
        }
        return true;
    }

    public void update() {
        if (!gameOver) {
        //keep updating the walls and the player if its not game over

            mapManager.update();
            player.update(playerPoint);
            sumPipe = mapManager.sumPipe;

            for (int i = 0; i < sumPipe; i++) {

                if (!MapManager.walls.get(i).playerCollide(player) && MapManager.walls.get(i).playerScore(player)) {
                    //for each pipe in on the screen is the player doesn't collide and they intersect the gap set boolean true
                    rectPoint=true;

                }
                if(rectPoint==true && MapManager.walls.get(i).pointTrigger(player)){

                    // if you've got through the gap the boolean is true
                    // when you get completely through and hit the trigger, add one point and set to false. This stops multiple points added.
                    score++;
                    rectPoint=false;

                }
            }
            MazeGame.txt_score.setText(""+ score);

        }
        if (mapManager.playerCollide(player)) {
            //if the player collides with the walls then set the game over boolean to true to show the game over screen

            gameOver = true;
        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        canvas.drawColor(Color.parseColor("#49caa6"));
        mapManager.draw(canvas);
        player.draw(canvas);

        //if the game over boolean is triggered show instructions to the player to tap to reset the game

        if (gameOver) {
            Paint paint = new Paint();
            paint.setTextSize(100);
            paint.setColor(Color.parseColor("#146585"));
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("game over", Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 2 - 150, paint);
            canvas.drawText("tap anywhere on the ", Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 2, paint);
            canvas.drawText("screen to try again", Constants.SCREEN_WIDTH / 2, Constants.SCREEN_HEIGHT / 2 + 100, paint);

        }
    }
}

