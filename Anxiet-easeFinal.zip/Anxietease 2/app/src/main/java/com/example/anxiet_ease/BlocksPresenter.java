package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageButton;

public class BlocksPresenter implements IPresenter {
    // Presenter for the Menu page for blocks activity
    private Context context;
    private Activity activity;

    public BlocksPresenter(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    @Override
    public void homeButton(ImageButton button) {
        button.setOnClickListener(r -> activity.finish());
    }

    public void slowStartButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, BlockEasy.class)));
    }

    public void normalStartButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, BlockMedium.class)));
    }

    public void fastStartButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, BlockHard.class)));
    }

}
