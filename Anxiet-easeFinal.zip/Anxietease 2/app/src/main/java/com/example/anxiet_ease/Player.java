package com.example.anxiet_ease;
// Sarina Saqib 2249047
//Inspiration for the basis of the maze game taken from ReteroChicken on youtube https://www.youtube.com/watch?v=OojQitoAEXs&t=2s&ab_channel=RetroChicken
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;

public class Player {
    private Rect rectangle;
    private int color;

    public Player(Rect rectangle, int color){
        //player is just a rectangle and a colour, the Rectangle is to make use of .Intersect to check if the player collides with obsticles
        this.rectangle = rectangle;
        this.color = color;

    }

    public Rect getRectangle(){
        return rectangle;
    }

    public void draw(Canvas canvas) {
        //drawing the player square on the canvas
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectangle,paint);

    }

    public void update(Point point){
        //giving the player a Point, this is in the middle of the Rect
        //for the player movement
        rectangle.set(point.x - rectangle.width()/2, point.y - rectangle.height()/2,
                point.x + rectangle.width()/2, point.y +rectangle.height()/2);

    }
}
