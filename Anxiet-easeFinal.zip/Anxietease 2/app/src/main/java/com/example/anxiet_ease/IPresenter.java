package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.widget.ImageButton;

public interface IPresenter {
    void homeButton(ImageButton button);
}
