package com.example.anxiet_ease;
// Sarina Saqib 2249047
import androidx.appcompat.app.AppCompatActivity;


import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.VideoView;

// Sarina Saqib 2249047
public class Breathe extends AppCompatActivity implements IView {

    //simple home button to finish the activity and go home
    // the XMl is where all work is done here
    private VideoView vv;
    private BreathePresenter presenter;
    private ImageButton backButton;
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breathe);
        setPresenter(new BreathePresenter(this.getContext(), this.getActivity()));

        vv = (VideoView)findViewById(R.id.breathevid);
        backButton = findViewById(R.id.breathehome);
        uri = Uri.parse("android.resource://com.example.anxiet_ease/"
                + R.raw.anxbreathe);
        presenter.homeButton(backButton);
        presenter.videoViewLoop(vv, uri);
    }


    private void setPresenter(BreathePresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}
