package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InfoPage extends AppCompatActivity implements IView {
    // mainly XMl purely informational page for the users to access actually psychological services if needed

    private InfoPagePresenter presenter;
    private ImageButton helpLineCall;
    private ImageButton infoHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_page);
        setPresenter(new InfoPagePresenter(this.getContext(), this.getActivity()));

        helpLineCall = findViewById(R.id.call);
        infoHome = findViewById(R.id.home);
        //find the textviews which have the links attached to them
        TextView adultLink = findViewById(R.id.NHSLink);
        TextView youthLink = findViewById(R.id.NHSYuteLink);
        TextView mindLink = findViewById(R.id.mindLink);

        presenter.homeButton(infoHome);
        presenter.callButton(helpLineCall);
        presenter.setLinks(adultLink, youthLink, mindLink);
    }

    private void setPresenter(InfoPagePresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}