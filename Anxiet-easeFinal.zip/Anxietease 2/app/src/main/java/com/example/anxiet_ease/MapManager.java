package com.example.anxiet_ease;
// Sarina Saqib 2249047
//Inspiration for the basis of the maze game taken from ReteroChicken on youtube https://www.youtube.com/watch?v=OojQitoAEXs&t=2s&ab_channel=RetroChicken


import android.graphics.Canvas;

import java.util.ArrayList;

public class MapManager {

    ///higher index = lower on screen = higher y value (higher the index further down screen it is)
    public static ArrayList<Walls> walls;
    private int playerGap;
    private int wallGap;
    private int wallHeight;
    private int color;
    private float speed;
    private long startTime;
    public int sumPipe;
    //public static int score = 0;

    public MapManager(int playerGap, int wallGap, int wallHeight, int color, float speed){
        this.playerGap = playerGap;
        this.wallGap = wallGap;
        this.wallHeight = wallHeight;
        this.color = color;
        this.speed = speed;
        startTime = System.currentTimeMillis();
        walls = new ArrayList<>();

        populateWalls();

    }

    public boolean playerCollide(Player player){
        //if the player hits either of the visible walls the boolean is true

        for (Walls x: walls){
            if(x.playerCollide(player))
                return true;

        }
        return false;
    }

    private void populateWalls(){
        //add the walls to the array and use the y to tell when to generate a new one on screen
        int currY = -5*Constants.SCREEN_HEIGHT/4;
        while (currY < 0){
            int xStart = (int) (Math.random()*(Constants.SCREEN_WIDTH - playerGap));
            walls.add( new Walls(wallHeight, color, xStart, currY, playerGap));
            currY += wallHeight + wallGap;

        }
    }

    public void update(){
        int elapsedTime = (int) (System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();

        //the update loop going through all the walls and making them move down the screen using the Y and time values
        //also gets rid of them when they hit the end of the screen
        for (Walls ob : walls){
            ob.incrementY(this.speed * elapsedTime);
        }
        if (walls.get(walls.size()-1).getWall1().top>= Constants.SCREEN_HEIGHT){
            int xStart = (int) (Math.random()*(Constants.SCREEN_WIDTH - playerGap));
            walls.add(0, new Walls(wallHeight, color, xStart,
                    walls.get(0).getWall1().top - wallHeight - wallGap, playerGap ));
            walls.remove(walls.size()-1 );

        }

        sumPipe = walls.size();
    }

    public void draw(Canvas canvas){
        //drawing the Array of Rects as walls on the screen
        for(Walls x : walls)
            x.draw(canvas);
    }

}
