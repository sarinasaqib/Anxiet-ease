package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity implements IView {

    private HomePresenter presenter;
    private Button mazeButton;
    private Button blocksButton;
    private Button soundsButton;
    private Button breatheButton;
    private ImageButton infoButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setPresenter(new HomePresenter(this.getContext()));

        mazeButton = findViewById(R.id.maze);
        blocksButton = findViewById(R.id.blocks);
        soundsButton = findViewById(R.id.sounds);
        breatheButton = findViewById(R.id.breathe);
        infoButton = findViewById(R.id.info);
        presenter.MazeButton(mazeButton);
        presenter.BlocksButton(blocksButton);
        presenter.SoundsButton(soundsButton);
        presenter.BreatheButton(breatheButton);
        presenter.InfoButton(infoButton);
    }

    private void setPresenter(HomePresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}







