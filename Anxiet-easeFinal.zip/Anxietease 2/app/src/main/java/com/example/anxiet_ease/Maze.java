package com.example.anxiet_ease;
// Sarina Saqib 2249047

import androidx.appcompat.app.AppCompatActivity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

public class Maze extends AppCompatActivity implements IView {

    private MazePresenter presenter;
    private ImageButton backButton;
    private Button mazeButtonSlow;
    private Button mazeButtonNormal;
    private Button mazeButtonFast;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maze);
        setPresenter(new MazePresenter(this.getContext(), this.getActivity()));

        backButton = findViewById(R.id.mazeHome);
        mazeButtonSlow = findViewById(R.id.slow);
        mazeButtonNormal = findViewById(R.id.normal);
        mazeButtonFast = findViewById(R.id.fast);

        presenter.homeButton(backButton);
        presenter.slowStartButton(mazeButtonSlow);
        presenter.normalStartButton(mazeButtonNormal);
        presenter.fastStartButton(mazeButtonFast);

    }

    private void setPresenter(MazePresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}