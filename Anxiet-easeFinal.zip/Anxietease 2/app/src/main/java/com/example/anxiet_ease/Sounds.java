package com.example.anxiet_ease;
// Sarina Saqib 2249047
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.Button;
import android.media.MediaPlayer;
import android.widget.ImageButton;

public class Sounds extends AppCompatActivity implements IView {

    private SoundsPresenter presenter;
    private ImageButton backButton;
    Button pinkNoiseControl;
    MediaPlayer pinkNoise;
    Button wavesControl;
    MediaPlayer waves;
    Button rainControl;
    MediaPlayer rain;
    Button birdsControl;
    MediaPlayer birds;
    Button classicalControl;
    MediaPlayer classical;
    Button lofiControl;
    MediaPlayer lofi;
    public Drawable pause;
    public Drawable play;


    @SuppressLint("UseCompatLoadingForDrawables")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sounds);

        backButton = findViewById(R.id.soundshome);
        wavesControl = findViewById(R.id.wavesctrl);
        waves = MediaPlayer.create(this, R.raw.wavesfinal);
        pinkNoiseControl = findViewById(R.id.forrest);
        pinkNoise = MediaPlayer.create(this, R.raw.pinknoisefinal);
        rainControl = findViewById(R.id.raincrl);
        rain = MediaPlayer.create(this, R.raw.rainfinal);
        classicalControl = findViewById(R.id.classicalcrl);
        classical = MediaPlayer.create(this, R.raw.classicalfinal);
        birdsControl = findViewById(R.id.birdscrl);
        birds = MediaPlayer.create(this, R.raw.birdsfinal);
        lofiControl = findViewById(R.id.loficrl);
        lofi = MediaPlayer.create(this, R.raw.lofifinal);

        pause = getResources().getDrawable(R.drawable.pauseclip);
        play = getResources().getDrawable(R.drawable.playclip);

        setPresenter(new SoundsPresenter(this.getContext(), this.getActivity(), play, pause,
                                        pinkNoiseControl, wavesControl, rainControl, birdsControl,
                                        classicalControl, lofiControl, pinkNoise, waves, rain,
                                        birds, classical, lofi));

        presenter.homeButton(backButton);
        presenter.wavesSound();
        presenter.pinkNoiseSound();
        presenter.birdSound();
        presenter.rainSound();
        presenter.classicalSound();
        presenter.lofiSound();

    }

    private void setPresenter(SoundsPresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }

}