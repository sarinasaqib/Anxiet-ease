package com.example.anxiet_ease;
// Sarina Saqib 2249047
public class Constants {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;

}
