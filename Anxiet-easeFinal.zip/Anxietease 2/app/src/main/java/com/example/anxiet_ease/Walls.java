package com.example.anxiet_ease;
// Sarina Saqib 2249047
//Inspiration for the basis of the maze game taken from ReteroChicken on youtube https://www.youtube.com/watch?v=OojQitoAEXs&t=2s&ab_channel=RetroChicken
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class Walls {
    private Rect wall1;
    private Rect wall2;
    private Rect gapRect;
    private Rect pointRect;
    private int color;

    public Walls(int rectHeight, int color, int startX, int startY, int playerGap ){
        //walls are generated in sets of 4, 1&2 are visible with gap between them and 3&4 are invisible point triggers

        this.color = color;
        pointRect = new Rect(0 , startY -187, Constants.SCREEN_WIDTH, startY-162);
        wall1 = new Rect(0, startY, startX, startY+rectHeight);
        wall2 = new Rect(startX+playerGap, startY, Constants.SCREEN_WIDTH, startY+rectHeight);
        gapRect = new Rect(startX, startY, startX+playerGap, startY+rectHeight);

    }

    public Rect getWall1(){
        return wall1;
    }

    public void incrementY(float y){
        wall1.top += y;
        wall1.bottom += y;
        wall2.top += y;
        wall2.bottom += y;
        gapRect.top+= y;
        gapRect.bottom+=y;
        pointRect.top+= y;
        pointRect.bottom+=y;

    }

    public boolean playerCollide (Player player) {
       //check for collisions with walls and player
        return Rect.intersects(wall1, player.getRectangle()) || Rect.intersects(wall2, player.getRectangle());
    }

    public boolean playerScore(Player player){
        // check if the player goes through invisible rectangle in the gap between the walls
        return Rect.intersects(gapRect, player.getRectangle());
    }

    public boolean pointTrigger(Player player){
        // point goes on when player fully clears the gap and intersects the Rect half way between next walls
        return Rect.intersects(pointRect, player.getRectangle());
    }

    public void draw(Canvas canvas){
        //draw all the walls to the canvas, Rect 1&2 being visible walls, 3&4 being invisible triggers
        Paint paint = new Paint();
        paint.setColor(color);
        Paint background = new Paint();

        background.setColor(Color.parseColor("#49caa6"));
        canvas.drawRect(pointRect,background);
        canvas.drawRect(wall1, paint);
        canvas.drawRect(wall2,paint);
        canvas.drawRect(gapRect, background);
    }
}
