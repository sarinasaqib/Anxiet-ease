package com.example.anxiet_ease;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.widget.ImageButton;
import android.widget.VideoView;

public class BreathePresenter implements IPresenter {
    // Presenter for the Breathe activity
    private Context context;
    private Activity activity;

    public BreathePresenter(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    public void videoViewLoop(VideoView video, Uri uri) {
        video.setVideoURI(uri);
        video.animate().alpha(1);
        video.requestFocus();

        video.start();
        video.setOnPreparedListener(mp -> mp.setLooping(true));
    }

    @Override
    public void homeButton(ImageButton button) {
        button.setOnClickListener(v -> {
            activity.finish();
        });
    }

}
