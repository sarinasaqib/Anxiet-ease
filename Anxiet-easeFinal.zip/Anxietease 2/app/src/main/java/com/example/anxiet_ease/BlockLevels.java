package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.widget.Button;
import android.widget.ImageButton;

// Interface from which the block levels extend
public interface BlockLevels extends IPresenter {
    void speedMenu(Button button);
    void clearGame();
    void resetButton(ImageButton button);
    void setRunning(boolean running);
    void targetButton();
    void destroy();
}
