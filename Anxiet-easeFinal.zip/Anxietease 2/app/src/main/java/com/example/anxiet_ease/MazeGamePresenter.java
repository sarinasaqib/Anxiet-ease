package com.example.anxiet_ease;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageButton;
// Sarina Saqib 2249047
public class MazeGamePresenter implements IPresenter {

    private Context context;
    private Activity activity;

    public MazeGamePresenter (Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    @Override
    public void homeButton(ImageButton button) {
        button.setOnClickListener(v -> {
            GamePanel.thread.setRunning(false);
            activity.finish();
            context.startActivity(new Intent(context, Home.class));
        });
    }

    public void speedMenu(Button button) {
        button.setOnClickListener(v -> {
            GamePanel.thread.setRunning(false);
            activity.finish();
        });
    }


}
