package com.example.anxiet_ease;
// Sarina Saqib 2249047
import androidx.appcompat.app.AppCompatActivity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;


public class Blocks extends AppCompatActivity implements IView {

    //start buttons to take the user to the class with the desired speed
    //each block speed used the same XML file activity_block
    private BlocksPresenter presenter;
    private ImageButton backButton;
    private Button blocksButtonSlow;
    private Button blocksButtonNormal;
    private Button blocksButtonFast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocks);
        setPresenter(new BlocksPresenter(this.getContext(), this.getActivity()));

        backButton = findViewById(R.id.blocksHome);
        blocksButtonSlow = findViewById(R.id.blocksSlow);
        blocksButtonNormal = findViewById(R.id.blocksMid);
        blocksButtonFast = findViewById(R.id.blocksFast);

        presenter.homeButton(backButton);
        presenter.slowStartButton(blocksButtonSlow);
        presenter.normalStartButton(blocksButtonNormal);
        presenter.fastStartButton(blocksButtonFast);

    }

    private void setPresenter(BlocksPresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }
}
