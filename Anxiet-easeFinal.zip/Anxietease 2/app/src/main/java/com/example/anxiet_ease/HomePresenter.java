package com.example.anxiet_ease;
// Sarina Saqib 2249047
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageButton;

public class HomePresenter implements IPresenter {
    // Presenter for the Home activity
    private Context context;

    public HomePresenter(Context context) {
        this.context = context;
    }

    public void MazeButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, Maze.class)));
    }

    public void BlocksButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, Blocks.class)));
    }

    public void SoundsButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, Sounds.class)));
    }

    public void BreatheButton(Button button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, Breathe.class)));
    }

    public void InfoButton(ImageButton button) {
        button.setOnClickListener(v -> context.startActivity(new Intent(context, InfoPage.class)));
    }

    @Override
    public void homeButton(ImageButton button) {
        // no home button on the home page
    }
}
